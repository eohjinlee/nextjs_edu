import Layout from "@/component/Layout";
import Article from "@/component/Article";

function  Welcome() {
  return <>
    <Article title="Welcome">Hello.</Article>
  </>
}

export default function Home() {
  return (
    <>
    <Welcome></Welcome>
    </>
  )
}
