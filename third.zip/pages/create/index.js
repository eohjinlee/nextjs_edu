import Article from "@/component/Article";
import { useRouter } from "next/router";

export default function Create() {
    const route = useRouter();
    return (
      <>
      <Article title={"Create"}>XD
        <form onSubmit={async (evt)=> {
            evt.preventDefault();
            const title = evt.target.title.value;
            const body  = evt.target.body.value;

            let options  = {
                method : "post",
                body   : JSON.stringify({
                    title : title,
                    body  : body
                }),
                headers : {
                    'Content-Type' : 'application/json'
                }
            };
            let response = await fetch("http://localhost:9999/topics", options);
            let result   = await response.json();
            route.push(`/read/${result.id}`);
        }}>
            <p>
                <input type="text" name="title" placeholder="제목"/>
            </p>
            <p>
                <textarea name="body" placeholder="본문"/>
            </p>
            <p>
                <input type="submit" value="create"/>
            </p>
        </form>
      </Article>
      </>
    )
  }
  