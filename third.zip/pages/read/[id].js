import Article from "@/component/Article";

export async function getServerSideProps(context) {
  const id = context.params.id;
  const response = await fetch(`http://localhost:9999/topics/${id}`);
  const result   = await response.json();
  return {
    props: {data:result}, // will be passed to the page component as props
  }
}

export default function Read({data}) {
  console.log(data);
  return (
    <>
    <Article title={data.title}>{data.body}</Article>
    </>
  )
}
  