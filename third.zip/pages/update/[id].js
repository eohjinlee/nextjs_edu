import Article from "@/component/Article";
import { useRouter } from "next/router";
import { useState } from "react";

export async function getServerSideProps(context) {
  const id = context.params.id;
  const response = await fetch(`http://localhost:9999/topics/${id}`);
  const result   = await response.json();
  return {
    props: {data:result}, // will be passed to the page component as props
  }
}

export default function Update({data}) {
  const route = useRouter();
  const [title, setTitle] = useState(data.title);
  const [body, setBody]   = useState(data.body);
  const id = data.id;
    return (
      <Article title="Update">
        <form onSubmit={async (evt)=> {
            evt.preventDefault();
            const title = evt.target.title.value;
            const body  = evt.target.body.value;

            let options  = {
                method : "PATCH",
                body   : JSON.stringify({
                    title : title,
                    body  : body
                }),
                headers : {
                    'Content-Type' : 'application/json'
                }
            };
            let response = await fetch(`http://localhost:9999/topics/${id}`, options);
            let result   = await response.json();
            route.push(`/read/${result.id}`);
        }}>
            <p>
                <input type="text" name="title" placeholder="제목" value={title} onChange={(evt)=>setTitle(evt.target.value)}/>
            </p>
            <p>
                <textarea name="body" placeholder="본문" value={body} onChange={(evt)=>setBody(evt.target.value)}/>
            </p>
            <p>
                <input type="submit" value="update"/>
            </p>
        </form>
      </Article>
    )
  }
  