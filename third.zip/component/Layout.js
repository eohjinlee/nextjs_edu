import Header from "@/component/Header";
import Nav from "@/component/Nav";
import { Button, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, Grid, TextField } from "@mui/material";
import { Container, Stack } from "@mui/system";
import { useRouter } from "next/router";
import { useState } from "react";

export default function Layout({children}) {
  const router = useRouter();
  const [isOpen, setIsOpen] = useState(true);

  let contextUI = null;
  if(router.query.id && router.asPath.startsWith("/read") > 0)
    contextUI = <>
      <Button variant="outlined" component={'Link'} href={`/update/${router.query.id}`}>Create</Button>
      <Button variant="outlined" component={'Link'} href={`/update/${router.query.id}`} onClick={()=>setIsOpen(true)}>Delete</Button>
    </>
  return <><Container maxWidth="md">
    <Dialog open={isOpen} onClose={()=>setIsOpen(false)}>Dialog
      <DialogTitle>삭제하시겠습니까?</DialogTitle>
      <DialogActions>
        <Button onClick={()=>{setIsOpen(false)}}>Delete</Button>
        <Button onClick={()=>{setIsOpen(false)}}>Cancel</Button>
      </DialogActions>
    </Dialog>
    <Header title="Payletter"></Header>
      <Grid container>    
        <Grid item md={3} xs={12}><Nav></Nav></Grid>
        <Grid item md={9} xs={12}>
          {children}<br/><br/>
          <Stack spacing={1} direction="row">
            <Button variant="outlined" component={'Link'} color="error" href="/create">Create</Button>
            {contextUI}
          </Stack>
          </Grid>
      </Grid>
  </Container>
  </>
}
