import Link from "next/link";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import * as React from 'react';
import CssBaseline from '@mui/material/CssBaseline';
import Box from '@mui/material/Box';
import Container from '@mui/material/Container';

export function FixedContainer() {
  return (
    <React.Fragment>
      <CssBaseline />
      <Container fixed>
        <Box sx={{ bgcolor: '#cfe8fc', height: '100vh' }} />
      </Container>
    </React.Fragment>
  );
}

export default function Nav() {
  const router = useRouter();
  const [topics, setTopics] = useState([]);
  async function init ()
  {
    let response = await fetch("http://localhost:9999/topics");
    let result   = await response.json();
    setTopics(result);
  }
  useEffect(() => {
    init();
    return () => {
      console.log("unmount");
    };
  }, [router.asPath]);
  const lis = topics.map((e) => <li key={e.id}><Link href={`/read/${e.id}`}>{e.title}</Link></li>);

  return <>
  <Container maxwidth="md">
    <nav>
      <ul>
        {lis}
      </ul>
    </nav>
  </Container>
  </>;
}
