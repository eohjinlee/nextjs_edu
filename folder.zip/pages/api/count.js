// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
const count = { value: 20 };

export default function handler(req, res) {  
  switch(req.method)
  {
    case "PATCH":
      count.value = req.body.value;
      break;
    case "GET":
      break;
  }
  res.status(200).json(count);
}

/*
let options = {
    method:"PATCH",
    headers:{"Content-Type" : "application/json"},
    body:JSON.stringify({value:20})
};
fetch("http://localhost:3000/api/count", options)
    .then(response => response.json())
    .then(result => console.log("result", result));
*/