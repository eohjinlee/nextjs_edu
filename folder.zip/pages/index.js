//import Layout from "/components/layout"
import {useState, useEffect} from 'react';
//getStaticProps build 할때 한번만 호출됨
export async function getServerSideProps(context) {
  console.log("getServerSideProps");
  const response = await fetch(process.env.NEXT_PUBLIC_API_URL + "api/count");
  const result   = await response.json();
  return {
    props: {value:result.value}, // will be passed to the page component as props
    //revalidate:10
  }
}


function Counter({downflag, count, onChangeValue}) {
  const [step,  setStep]  = useState(1);

  return <>
    <input type="number" value={step} onChange={evt => {
      setStep(Number(evt.target.value));
    }}/>&nbsp;
    <input type="button" value="+" onClick={() => {32
      onChangeValue(count + step);
    }} />&nbsp;
    {downflag ? <input type="button" value="-" /> : null}  
  </>
}

export default function Home(props) {
  console.log("Home", props);
  const [count, setCount] = useState(props.value);
  /*
  useEffect(() => {
    fetch("http://localhost:3000/api/count")
    .then(response => response.json())
    .then(result   => setCount(result.value));
  }, []);
  */
  return (
    <>
      {/* <Layout>Counter</Layout> */}
      Counter&nbsp;<br/>
      {count}&nbsp;
      <Counter downflag={false} count={count} onChangeValue={(newValue) => {
        let options = {
            method:"PATCH",
            headers:{"Content-Type" : "application/json"},
            body:JSON.stringify({value:newValue})
        };
        fetch(process.env.NEXT_PUBLIC_API_URL + "api/count", options)
            .then(response => response.json())
            .then(result => setCount(result.value));
      }}></Counter>
    </>
  )
}
