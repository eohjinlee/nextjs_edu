import Layout from "/components/layout"

export default function About() {
    return (
      <>
        About
      </>
    )
  }