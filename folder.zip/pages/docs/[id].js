import Layout from "/components/layout"
import { useRouter } from "next/router"
export async function getServerSideProps(context) {
    return {
        props:{}
    }
}

export default function Docs() {
    const router = useRouter();
    console.log("useRouter", router.query);

    return (
      <>
        Docs{router.query.id}
      </>
    )
  }