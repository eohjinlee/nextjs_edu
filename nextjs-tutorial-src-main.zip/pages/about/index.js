import Link from 'next/link';
export default function About(){
  return (
  <>
    <h2>About</h2>
    This app is ...
  </>
)
}