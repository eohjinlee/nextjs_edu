# 저장소 소개
카운터 앱을 구현하면서 Nextjs의 여러 개념들을 익혀가는 예제 중심의 자습서입니다. 

# 사용방법 
버전마다 댓글이 달려있습니다. 첫 댓글이 버전에 대한 설명입니다. 댓글을 참조해서 실습을 진행하면 됩니다.  
https://github.com/egoing/nextjs-tutorial-src/commits/main

# 준비물
- nodejs
- visual studio code

# 의견 및 질문은 각 버전의 댓글을 이용해주세요. 